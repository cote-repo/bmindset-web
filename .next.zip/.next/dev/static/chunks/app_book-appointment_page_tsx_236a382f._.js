(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9fef1067._.js",
  "static/chunks/node_modules_e8eb4db1._.js"
],
    source: "dynamic"
});
