(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e169c77d._.js",
  "static/chunks/node_modules_0138273b._.js"
],
    source: "dynamic"
});
