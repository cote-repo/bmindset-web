var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/appointment/route.js")
R.c("server/chunks/node_modules_0ad5342d._.js")
R.c("server/chunks/[root-of-the-server]__07ddd1bb._.js")
R.c("server/chunks/_next-internal_server_app_api_appointment_route_actions_b1887e19.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/appointment/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/appointment/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
