module.exports = [
"[project]/.next-internal/server/app/gis-platform/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gis-platform_page_actions_de17b06f.js.map