module.exports = [
"[project]/.next-internal/server/app/satellite-data-analytics/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_satellite-data-analytics_page_actions_47d0ea97.js.map