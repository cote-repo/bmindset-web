module.exports = [
"[project]/.next-internal/server/app/smart-city-gis/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_smart-city-gis_page_actions_609d09da.js.map