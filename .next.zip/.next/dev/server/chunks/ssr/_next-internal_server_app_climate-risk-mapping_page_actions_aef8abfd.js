module.exports = [
"[project]/.next-internal/server/app/climate-risk-mapping/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_climate-risk-mapping_page_actions_aef8abfd.js.map