module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},85790,e=>{"use strict";var t=e.i(47909),r=e.i(74017),n=e.i(96250),o=e.i(59756),a=e.i(61916),s=e.i(14444),i=e.i(37092),l=e.i(69741),p=e.i(16795),d=e.i(87718),u=e.i(95169),c=e.i(47587),m=e.i(66012),h=e.i(70101),x=e.i(26937),g=e.i(10372),f=e.i(93695);e.i(52474);var v=e.i(220),y=e.i(89171),R=e.i(29508);async function E(e){try{let{name:t,email:r,phone:n,company:o,topic:a,date:s,time:i}=await e.json();if(!t||!r||!n||!a||!s||!i)return y.NextResponse.json({error:"All required fields must be filled"},{status:400});let l=new Date(s).toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"}),p=R.default.createTransport({host:process.env.SMTP_HOST??"smtp.gmail.com",port:Number(process.env.SMTP_PORT??587),secure:(process.env.SMTP_SECURE??"false")==="true",auth:{user:process.env.SMTP_EMAIL,pass:process.env.SMTP_PASSWORD},...process.env.SMTP_TLS_REJECT_UNAUTHORIZED?{tls:{rejectUnauthorized:"false"!==process.env.SMTP_TLS_REJECT_UNAUTHORIZED}}:{}});await p.verify();let d={from:process.env.SMTP_EMAIL,to:process.env.APPOINTMENT_TO_EMAIL??"info@bmindsets.com",replyTo:r,subject:`New Appointment Request - ${t} on ${l}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0369a1; border-bottom: 2px solid #0369a1; padding-bottom: 10px;">
            New Appointment Booking
          </h2>
          <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0369a1; margin-top: 0;">Appointment Details</h3>
            <p><strong>Date:</strong> ${l}</p>
            <p><strong>Time:</strong> ${i}</p>
            
            <h3 style="color: #0369a1;">Contact Information</h3>
            <p><strong>Name:</strong> ${t}</p>
            <p><strong>Email:</strong> ${r}</p>
            <p><strong>Phone:</strong> ${n}</p>
            ${o?`<p><strong>Company:</strong> ${o}</p>`:""}
            
            <h3 style="color: #0369a1;">Discussion Topic</h3>
            <p style="background-color: white; padding: 15px; border-radius: 4px; border-left: 4px solid #0369a1;">
              ${a.replace(/\n/g,"<br>")}
            </p>
          </div>
          <p style="color: #64748b; font-size: 12px;">
            This appointment was booked from the BMINDSET TECHNOLOGY website.
          </p>
        </div>
      `},u={from:process.env.SMTP_EMAIL,to:r,subject:"Appointment Confirmed - BMINDSET TECHNOLOGY",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="text-align: center; padding: 20px 0;">
            <h1 style="color: #0369a1; margin: 0;">BMINDSET TECHNOLOGY</h1>
            <p style="color: #64748b; margin: 5px 0;">GIS & Geospatial Solutions</p>
          </div>
          
          <h2 style="color: #0369a1; border-bottom: 2px solid #0369a1; padding-bottom: 10px;">
            Your Appointment is Confirmed!
          </h2>
          
          <p>Dear ${t},</p>
          <p>Thank you for scheduling an appointment with BMINDSET TECHNOLOGY. We look forward to speaking with you!</p>
          
          <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <h3 style="color: #0369a1; margin-top: 0;">Appointment Details</h3>
            <p style="font-size: 18px; margin: 10px 0;"><strong>${l}</strong></p>
            <p style="font-size: 24px; color: #0369a1; font-weight: bold; margin: 10px 0;">${i}</p>
          </div>
          
          <div style="background-color: #f0f9ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Discussion Topic:</strong></p>
            <p style="margin: 10px 0 0 0;">${a}</p>
          </div>
          
          <p>If you need to reschedule or cancel your appointment, please contact us at:</p>
          <ul style="list-style: none; padding: 0;">
            <li>Email: <a href="mailto:info@bmindsets.com" style="color: #0369a1;">info@bmindsets.com</a></li>
            <li>Phone: <a href="tel:+919493604752" style="color: #0369a1;">+91 9493604752</a></li>
          </ul>
          
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
          
          <p style="color: #64748b; font-size: 12px; text-align: center;">
            BMINDSET TECHNOLOGY | Unleashing the Power of Maps & Satellite Data<br>
            <a href="https://www.bmindsets.com" style="color: #0369a1;">www.bmindsets.com</a>
          </p>
        </div>
      `};return await Promise.all([p.sendMail(d),p.sendMail(u)]),y.NextResponse.json({success:!0,message:"Appointment booked successfully"})}catch(e){return console.error("Error booking appointment:",e),y.NextResponse.json({error:"Failed to book appointment. Please try again later."},{status:500})}}e.s(["POST",()=>E],4761);var b=e.i(4761);let w=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/appointment/route",pathname:"/api/appointment",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/appointment/route.ts",nextConfigOutput:"",userland:b}),{workAsyncStorage:T,workUnitAsyncStorage:A,serverHooks:C}=w;function S(){return(0,n.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:A})}async function N(e,t,n){w.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let y="/api/appointment/route";y=y.replace(/\/index$/,"")||"/";let R=await w.prepare(e,t,{srcPage:y,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:E,params:b,nextConfig:T,parsedUrl:A,isDraftMode:C,prerenderManifest:S,routerServerContext:N,isOnDemandRevalidate:P,revalidateOnlyGenerated:O,resolvedPathname:M,clientReferenceManifest:_,serverActionsManifest:k}=R,D=(0,l.normalizeAppPath)(y),I=!!(S.dynamicRoutes[D]||S.routes[M]),H=async()=>((null==N?void 0:N.render404)?await N.render404(e,t,A,!1):t.end("This page could not be found"),null);if(I&&!C){let e=!!S.routes[M],t=S.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(T.experimental.adapterPath)return await H();throw new f.NoFallbackError}}let j=null;!I||w.isDev||C||(j="/index"===(j=M)?"/":j);let q=!0===w.isDev||!I,U=I&&!q;k&&_&&(0,s.setReferenceManifestsSingleton)({page:y,clientReferenceManifest:_,serverActionsManifest:k,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:k})});let $=e.method||"GET",L=(0,a.getTracer)(),B=L.getActiveScopeSpan(),G={params:b,prerenderManifest:S,renderOpts:{experimental:{authInterrupts:!!T.experimental.authInterrupts},cacheComponents:!!T.cacheComponents,supportsDynamicResponse:q,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:T.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>w.onRequestError(e,t,n,N)},sharedContext:{buildId:E}},F=new p.NodeNextRequest(e),K=new p.NodeNextResponse(t),z=d.NextRequestAdapter.fromNodeNextRequest(F,(0,d.signalFromNodeResponse)(t));try{let s=async e=>w.handle(z,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=L.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=r.get("next.route");if(n){let t=`${$} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":t}),e.updateName(t)}else e.updateName(`${$} ${y}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),l=async o=>{var a,l;let p=async({previousCacheEntry:r})=>{try{if(!i&&P&&O&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await s(o);e.fetchMetrics=G.renderOpts.fetchMetrics;let l=G.renderOpts.pendingWaitUntil;l&&n.waitUntil&&(n.waitUntil(l),l=void 0);let p=G.renderOpts.collectedTags;if(!I)return await (0,m.sendResponse)(F,K,a,G.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(a.headers);p&&(t[g.NEXT_CACHE_TAGS_HEADER]=p),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=g.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,n=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=g.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==r?void 0:r.isStale)&&await w.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:P})},N),t}},d=await w.handleResponse({req:e,nextConfig:T,cacheKey:j,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:P,revalidateOnlyGenerated:O,responseGenerator:p,waitUntil:n.waitUntil,isMinimalMode:i});if(!I)return null;if((null==d||null==(a=d.value)?void 0:a.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(l=d.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",P?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(d.value.headers);return i&&I||u.delete(g.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,x.getCacheControlHeader)(d.cacheControl)),await (0,m.sendResponse)(F,K,new Response(d.value.body,{headers:u,status:d.value.status||200})),null};B?await l(B):await L.withPropagatedContext(e.headers,()=>L.trace(u.BaseServerSpan.handleRequest,{spanName:`${$} ${y}`,kind:a.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},l))}catch(t){if(t instanceof f.NoFallbackError||await w.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:P})}),I)throw t;return await (0,m.sendResponse)(F,K,new Response(null,{status:500})),null}}e.s(["handler",()=>N,"patchFetch",()=>S,"routeModule",()=>w,"serverHooks",()=>C,"workAsyncStorage",()=>T,"workUnitAsyncStorage",()=>A],85790)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__ef4ee1cf._.js.map