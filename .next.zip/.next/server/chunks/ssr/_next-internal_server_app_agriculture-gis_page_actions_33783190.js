module.exports=[10720,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agriculture-gis_page_actions_33783190.js.map