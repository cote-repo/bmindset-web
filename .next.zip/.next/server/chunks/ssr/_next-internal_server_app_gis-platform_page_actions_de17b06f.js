module.exports=[73484,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gis-platform_page_actions_de17b06f.js.map