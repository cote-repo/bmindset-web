module.exports=[57344,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_satellite-data-analytics_page_actions_47d0ea97.js.map