module.exports=[13595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_geospatial-analytics_page_actions_31d37382.js.map