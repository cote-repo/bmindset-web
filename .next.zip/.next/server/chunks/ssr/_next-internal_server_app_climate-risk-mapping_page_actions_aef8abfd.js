module.exports=[58147,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_climate-risk-mapping_page_actions_aef8abfd.js.map