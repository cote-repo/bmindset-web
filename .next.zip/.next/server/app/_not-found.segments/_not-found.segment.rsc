1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/b028f406cb81fced.js","/_next/static/chunks/247eb132b7f7b574.js"],"default"]
3:I[37457,["/_next/static/chunks/b028f406cb81fced.js","/_next/static/chunks/247eb132b7f7b574.js"],"default"]
0:{"buildId":"gkn7o_wRDHbqq-UjWtTIf","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
