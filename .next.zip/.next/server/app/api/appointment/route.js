var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/appointment/route.js")
R.c("server/chunks/[root-of-the-server]__ef4ee1cf._.js")
R.c("server/chunks/[root-of-the-server]__124fd942._.js")
R.c("server/chunks/_next-internal_server_app_api_appointment_route_actions_b1887e19.js")
R.m(85790)
module.exports=R.m(85790).exports
